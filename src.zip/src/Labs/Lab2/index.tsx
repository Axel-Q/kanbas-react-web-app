export default function Lab2() {
    return (
        <div>
            <h2>Lab2</h2>
        </div>
    );
}